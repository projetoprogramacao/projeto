package javaapplication1;

public class Time implements Comparable<Time> {

    private String nome;
    private int codigo = 0, pontuacao = 0, vitorias = 0, empates = 0, derrotas = 0, golsMarcados = 0, golsSofridos = 0, saldoDeGols = 0;
    private double aproveitamento = 0;

    // CONTRUTORES
    public Time(String nome) {
        this.nome = nome;
    }

    public Time() {
    }

    //GETS 'N SETS
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPontuacao() {
        return pontuacao;
    }

    public void setPontuacao(int pontuacao) {
        this.pontuacao = pontuacao;
    }

    public int getVitorias() {
        return vitorias;
    }

    public void setVitorias(int vitorias) {
        this.vitorias = vitorias;
    }

    public int getDerrotas() {
        return derrotas;
    }

    public void setDerrotas(int derrotas) {
        this.derrotas = derrotas;
    }

    public int getEmpates() {
        return empates;
    }

    public void setEmpates(int empates) {
        this.empates = empates;
    }

    public int getGolsMarcados() {
        return golsMarcados;
    }

    public void setGolsMarcados(int golsMarcados) {
        this.golsMarcados = golsMarcados;
    }

    public int getGolsSofridos() {
        return golsSofridos;
    }

    public void setGolsSofridos(int golsSofridos) {
        this.golsSofridos = golsSofridos;
    }

    public int getSaldoDeGols() {
        return saldoDeGols;
    }

    public void setSaldoDeGols(int saldoDeGols) {
        this.saldoDeGols = saldoDeGols;
    }

    public double getAproveitamento() {
        return aproveitamento;
    }

    public void setAproveitamento(double aproveitamento) {
        this.aproveitamento = aproveitamento;
    }

    //MÉTODOS
    @Override
    public String toString() {
        return "Clube" + codigo + ": " + nome;
    }

    @Override
    public int compareTo(Time o) {
        if (this.pontuacao > o.pontuacao) {
            return -1;
        }

        if (this.pontuacao < o.pontuacao) {
            return 1;
        }

        if (this.pontuacao == o.pontuacao) {

            if (this.vitorias > o.vitorias) {
                return -1;
            }

            if (this.vitorias < o.vitorias) {
                return 1;
            }

            if (this.vitorias == o.vitorias) {

                if (this.saldoDeGols > o.saldoDeGols) {
                    return -1;
                }

                if (this.saldoDeGols < o.saldoDeGols) {
                    return 1;
                }
            }
        }
        return 0;
    }
}

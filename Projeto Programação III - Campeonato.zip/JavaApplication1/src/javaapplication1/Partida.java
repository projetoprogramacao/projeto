package javaapplication1;

import java.util.HashSet;
import java.util.Scanner;

public class Partida {

    Scanner s = new Scanner(System.in);
    private int golsMandante = 0, golsVisitante = 0;
    private String resultado = null;

    Time a = new Time();
    Time b = new Time();
    Time vencedor = new Time();

    // CONTRUTORES
    public Partida(Time a, Time b) {
        this.b = b;
        this.a = a;
    }

    // GETS 'N SETS
    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public int getGolsMandante() {
        return golsMandante;
    }

    public void setGolsMandante(int golsMandante) {
        this.golsMandante = golsMandante;
    }

    public int getGolsVisitante() {
        return golsVisitante;
    }

    public void setGolsVisitante(int golsVisitante) {
        this.golsVisitante = golsVisitante;
    }

    public Time getA() {
        return a;
    }

    public void setA(Time a) {
        this.a = a;
    }

    public Time getB() {
        return b;
    }

    public void setB(Time b) {
        this.b = b;
    }

    public Time getVencedor() {
        return vencedor;
    }

    public void setVencedor(Time vencedor) {
        this.vencedor = vencedor;
    }
    // TO STRING

    @Override
    public String toString() {
        return "Partida{" + a + " x " + b + '}';
    }

    //MÉTODOS
    public void geraResultado() {

        System.out.println(a.getNome() + " " + golsMandante + " X " + golsVisitante + " " + b.getNome());

        if (golsMandante > golsVisitante) {

            vencedor = a;

            a.setPontuacao(3 + a.getPontuacao());
            a.setVitorias(a.getVitorias() + 1);
            a.setGolsSofridos(a.getGolsSofridos() + golsVisitante);
            a.setGolsMarcados(a.getGolsMarcados() + golsMandante);
            a.setSaldoDeGols(a.getSaldoDeGols() + golsMandante);
            a.setSaldoDeGols(a.getSaldoDeGols() - golsVisitante);

            b.setDerrotas(b.getDerrotas() + 1);
            b.setGolsSofridos(b.getGolsSofridos() + golsMandante);
            b.setGolsMarcados(b.getGolsMarcados() + golsVisitante);
            b.setSaldoDeGols(b.getSaldoDeGols() + golsVisitante);
            b.setSaldoDeGols(b.getSaldoDeGols() - golsMandante);

            resultado = (a.getNome() + " " + golsMandante + " X " + b.getNome() + " " + golsVisitante);

        } else if (golsMandante < golsVisitante) {

            vencedor = b;

            b.setPontuacao(3 + b.getPontuacao());
            b.setVitorias(b.getVitorias() + 1);
            b.setGolsSofridos(b.getGolsSofridos() + golsMandante);
            b.setGolsMarcados(b.getGolsMarcados() + golsVisitante);
            b.setSaldoDeGols(b.getSaldoDeGols() + golsVisitante);
            b.setSaldoDeGols(b.getSaldoDeGols() - golsMandante);

            a.setDerrotas(a.getDerrotas() + 1);
            a.setGolsSofridos(a.getGolsSofridos() + golsVisitante);
            a.setGolsMarcados(a.getGolsMarcados() + golsMandante);
            a.setSaldoDeGols(a.getSaldoDeGols() + golsMandante);
            a.setSaldoDeGols(a.getSaldoDeGols() - golsVisitante);

            resultado = (a.getNome() + " " + golsMandante + " X " + b.getNome() + " " + golsVisitante);

        } else {
            a.setPontuacao(1 + a.getPontuacao());
            a.setEmpates(a.getEmpates() + 1);
            a.setGolsSofridos(a.getGolsSofridos() + golsVisitante);
            a.setGolsMarcados(a.getGolsMarcados() + golsMandante);

            b.setPontuacao(1 + b.getPontuacao());
            b.setEmpates(b.getEmpates() + 1);
            b.setGolsSofridos(b.getGolsSofridos() + golsMandante);
            b.setGolsMarcados(b.getGolsMarcados() + golsVisitante);

            resultado = (a.getNome() + " " + golsMandante + " X " + b.getNome() + " " + golsVisitante);

            vencedor = null;

        }
    }

}

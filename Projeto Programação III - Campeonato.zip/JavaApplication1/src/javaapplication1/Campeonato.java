package javaapplication1;

import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.Icon;
import javax.swing.JLabel;

public class Campeonato {

    private ArrayList<Time> times = new ArrayList(); // ARRAY DE TIMES
    private ArrayList<Partida> partidas = new ArrayList(); //ARRAY DE PARTIDAS
    static int codigoTime = 1; //SERIAL IDENTIFICADOR PARA CADA TIME
    Scanner ler = new Scanner(System.in);
    private String nomeCamp;
    private int numeroDeTimes;

    //CONTRUTORES
    public Campeonato(String nomeCamp) {
        this.nomeCamp = nomeCamp;
    }

    public Campeonato() {
    }

    //GETS E STES
    public static void setCodigoTime(int codigoTime) {
        Campeonato.codigoTime = codigoTime;
    }

    public static int getCodigoTime() {
        return codigoTime;
    }

    public ArrayList<Time> getTimes() {
        return times;
    }

    public void setNomeCamp(String nomeCamp) {
        this.nomeCamp = nomeCamp;
    }

    public String getNomeCamp() {
        return nomeCamp;
    }

    public void setNumeroDeTimes(int numeroDeTimes) {
        this.numeroDeTimes = numeroDeTimes;
    }

    public int getNumeroDeTimes() {
        return numeroDeTimes;
    }

    public ArrayList<Partida> getPartidas() {
        return partidas;
    }

    //METODOS
    public void criarCampeonato(String nomeCamp) {
        Campeonato c = new Campeonato(nomeCamp);
    }

    public void inserirTime(String t) {
        Time a = new Time(t);
        a.setCodigo(codigoTime);
        codigoTime++;
        times.add(a);
    }

    public void geraConfrontos(int numeroDeTimes) {
        for (int i = 0; i <= numeroDeTimes - 1; i++) {
            for (int j = 0; j <= numeroDeTimes - 1; j++) {
                Partida p = new Partida(times.get(i), times.get(j));
                if (p.getA() != p.getB()) {
                    partidas.add(p);
                }
            }
        }
    }

    public void exibeConfrontos() {
        for (Partida pp : partidas) { //EXIBE AS PARTIDAS-CONFRONTOS
            System.out.println(pp);
        }
    }

    public void exibeTabela() {
        System.out.println("Time" + " / " + " P" + " / " + "V" + " / " + "D" + " / " + "E" + " / " + " S " + " / " + "GP" + " / " + "GS");
        for (int i = 0; i <= times.size() - 1; i++) {
            System.out.println(times.get(i).getNome());
            System.out.println(" / " + times.get(i).getPontuacao() + " / " + times.get(i).getVitorias() + " / " + times.get(i).getDerrotas() + " / " + times.get(i).getEmpates() + " / " + times.get(i).getSaldoDeGols() + " / " + times.get(i).getGolsMarcados() + " / " + times.get(i).getGolsSofridos());
        }
    }

    public boolean procurarTime(String time) {
        boolean achou = false;
        for (Time t : times) {
            if (t.getNome().equals(time)) {
                achou = true;
            } else {
                achou = false;
            }
        }
        return achou;
    }

}

package javaapplication1;
/*
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class JavaApplication1 {

    Set<Campeonato> campeonatos = new HashSet<>();

    static void Menu01() {

        System.out.println("Championship Plus");
        System.out.println(" ");
        System.out.println("Menu ");
        System.out.println(" ");
        System.out.println("01. Novo campeonato ");
        System.out.println("02. Últimos campeões ");
        System.out.println("03. Encerrar ");

    }

    public static void main(String[] args) {
        
        
        Scanner ler = new Scanner(System.in);
        int opMenu = 99;

//EXIBE E LE O MENU 01
        Menu01();
        opMenu = ler.nextInt();
        ler.nextLine();

//LAÇO DO PRIMEIRO MENU
//DO 1
        while (opMenu != 3) {
            switch (opMenu) {
                case 1:
                    int opMenu2 = 99;
                    String nomeCamp;

//CRIA UM CAMPEONATO
                    System.out.println("Informe o nome do campeonato: ");
                    nomeCamp = ler.nextLine();
                    Campeonato c = new Campeonato(nomeCamp);
                    System.out.println(" ");
                    System.out.println(c.getNomeCamp() + " Cadastrado com sucesso");
                    System.out.println(" ");

//CADATRAR TIMES
                    c.cadastrarTimes();

                    System.out.println(" ");
                    System.out.println("01. Exibir confrontos ");
                    System.out.println("02. Computar resultados ");
                    System.out.println("03. Voltar ");
                    System.out.println(" ");

                    opMenu2 = ler.nextInt();
                    ler.nextLine();

//DO 2
                    while (opMenu2 != 3) {
                        switch (opMenu2) {
//EXIBE CONFRONTOS
                            case 1: //EXIBIR CONFRONTOS
                                for (Partida p : c.getPartidas()) {
                                    System.out.println(p);
                                }
                                System.out.println(" ");
                                System.out.println("01. Exibir confrontos ");
                                System.out.println("02. Computar resultados ");
                                System.out.println("03. Voltar ");
                                System.out.println(" ");

                                opMenu2 = ler.nextInt();
                                ler.nextLine();
                                break;

//COMPUTAR RESULTADOS
                            case 2: //COMPUTAR RESULTADOS
                                for (Partida p : c.getPartidas()) {
                                    p.geraResultado();
                                }
                                System.out.println("01. Exibir classificação ");
                                System.out.println("02. Exibir resultados ");
                                System.out.println("03. Reiniciar ");
                                System.out.println("04. Encerrar ");

                                int opMenu3 = 99;
                                opMenu3 = ler.nextInt();
                                while (opMenu3 != 4) {
                                    switch (opMenu3) {
                                        case 1:
                                            c.exibeTabela();
                                            System.out.println("01. Exibir classificação ");
                                            System.out.println("02. Exibir resultados ");
                                            System.out.println("03. Reiniciar ");
                                            System.out.println("04. Encerrar ");
                                            opMenu3 = ler.nextInt();
                                            break;
                                        case 2:
                                            for (Partida p : c.getPartidas()) {
                                                System.out.println(p.getResultado());
                                            }
                                            System.out.println("01. Exibir classificação ");
                                            System.out.println("02. Exibir resultados ");
                                            System.out.println("03. Reiniciar ");
                                            System.out.println("04. Encerrar ");
                                            opMenu3 = ler.nextInt();
                                            break;
                                        case 3:
                                            opMenu2 = 3;
                                            opMenu3 = 4;
                                            break;
                                        case 4:
                                            opMenu = 3;
                                            break;
                                    }
                                }
                                break;
//VOLTAR PARA MENU 1
                            case 3:
                                break;
                        }
                    }
                    break;

                case 2:
                    System.out.println("02. Computar resultados ");
                    break;
                case 3:
                    System.out.println("03. Voltar ");
                    break;
            }
            //REINICIA O LOOP INICIAL
            System.out.println("Championship Plus");
            System.out.println(" ");
            System.out.println("Menu ");
            System.out.println(" ");
            System.out.println("01. Novo campeonato ");
            System.out.println("02. Últimos campeões ");
            System.out.println("03. Encerrar ");
            opMenu = ler.nextInt();
            ler.nextLine();
        }
    }
}
*/
package GUI;

import java.util.ArrayList;
import javaapplication1.Campeonato;
import javaapplication1.Time;

public class APP {

    static ArrayList<Campeonato> campeonatos = new ArrayList<>();
    static ArrayList<Time> galeria = new ArrayList<>();
    static int contCamp = 0;

    public static void main(String[] args) {
        new GUI1().setVisible(true);
    }
}

package GUI;

import static GUI.APP.campeonatos;
import static GUI.APP.contCamp;
import javaapplication1.Time;

public class GUI32 extends javax.swing.JFrame {

    Time time1, time2, time3, time4;

    public GUI32() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jtfTime01 = new javax.swing.JTextField();
        jlabTime01 = new javax.swing.JLabel();
        jabTime02 = new javax.swing.JLabel();
        jtfTime02 = new javax.swing.JTextField();
        jtfTime03 = new javax.swing.JTextField();
        jlabTime03 = new javax.swing.JLabel();
        jlabTime4 = new javax.swing.JLabel();
        jtfTime04 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Cadastro de times");

        jtfTime01.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfTime01ActionPerformed(evt);
            }
        });

        jlabTime01.setText("Time 01:");

        jabTime02.setText("Time 02:");

        jtfTime02.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfTime02ActionPerformed(evt);
            }
        });

        jtfTime03.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfTime03ActionPerformed(evt);
            }
        });

        jlabTime03.setText("Time 03:");

        jlabTime4.setText("Time 04:");

        jtfTime04.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfTime04ActionPerformed(evt);
            }
        });

        jButton1.setText("Avançar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jlabTime4)
                            .addComponent(jlabTime03))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtfTime03, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtfTime04, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jabTime02)
                            .addComponent(jlabTime01))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtfTime01, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtfTime02, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(151, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlabTime01)
                    .addComponent(jtfTime01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jabTime02)
                    .addComponent(jtfTime02, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlabTime03)
                    .addComponent(jtfTime03, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlabTime4)
                    .addComponent(jtfTime04, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(50, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jtfTime01ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfTime01ActionPerformed
        if (evt.getSource() == jtfTime01) {
            campeonatos.get(contCamp).inserirTime(evt.getActionCommand());
            System.out.println(campeonatos.get(contCamp).getTimes());
        }    }//GEN-LAST:event_jtfTime01ActionPerformed

    private void jtfTime02ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfTime02ActionPerformed
        if (evt.getSource() == jtfTime02) {
            campeonatos.get(contCamp).inserirTime(evt.getActionCommand());
            System.out.println(campeonatos.get(contCamp).getTimes());

        }    }//GEN-LAST:event_jtfTime02ActionPerformed

    private void jtfTime03ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfTime03ActionPerformed
        if (evt.getSource() == jtfTime03) {
            campeonatos.get(contCamp).inserirTime(evt.getActionCommand());
            System.out.println(campeonatos.get(contCamp).getTimes());

        }    }//GEN-LAST:event_jtfTime03ActionPerformed

    private void jtfTime04ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfTime04ActionPerformed
        if (evt.getSource() == jtfTime04) {
            campeonatos.get(contCamp).inserirTime(evt.getActionCommand());
            System.out.println(campeonatos.get(contCamp).getTimes());

        }    }//GEN-LAST:event_jtfTime04ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (evt.getSource() == jButton1) {
            GUI32.this.dispose();
            new GUI04().setVisible(true);
        }    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI32().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jabTime02;
    private javax.swing.JLabel jlabTime01;
    private javax.swing.JLabel jlabTime03;
    private javax.swing.JLabel jlabTime4;
    private javax.swing.JTextField jtfTime01;
    private javax.swing.JTextField jtfTime02;
    private javax.swing.JTextField jtfTime03;
    private javax.swing.JTextField jtfTime04;
    // End of variables declaration//GEN-END:variables
}

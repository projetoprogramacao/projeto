package GUI;

import static GUI.APP.campeonatos;
import static GUI.APP.contCamp;
import javaapplication1.Campeonato;

public class GUI21 extends javax.swing.JFrame {

    private int qtdTimes = 0;
    private Integer[] numTimes = {0, 2, 4, 6, 8};

    public GUI21() {
        initComponents();
    }

    public int getQtdTimes() {
        return qtdTimes;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jtfNomeDoCampeonato = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jbtAvancar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jtfNomeDoCampeonato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfNomeDoCampeonatoActionPerformed(evt);
            }
        });

        jLabel1.setText("Nome do Campeonato:");

        jLabel2.setText("Quantidade de times");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "2", "4" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jbtAvancar.setText("Avançar");
        jbtAvancar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtAvancarActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel3.setText("O nome do campeonato não foi cadastrado corretamente.");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel4.setText("Tente novamente.");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel5.setText("Lembre-se de pressionar Enter após digitar na caixa de texto.");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                        .addComponent(jLabel1)
                        .addComponent(jLabel2)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jbtAvancar)
                        .addComponent(jtfNomeDoCampeonato, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(70, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addGap(7, 7, 7)
                .addComponent(jLabel5)
                .addGap(30, 30, 30)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtfNomeDoCampeonato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jbtAvancar)
                .addContainerGap(92, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jtfNomeDoCampeonatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfNomeDoCampeonatoActionPerformed
        if (evt.getSource() == jtfNomeDoCampeonato) {
            Campeonato a = new Campeonato(evt.getActionCommand());
            campeonatos.add(a);
            System.out.println(campeonatos.get(contCamp).getNomeCamp());
        }

    }//GEN-LAST:event_jtfNomeDoCampeonatoActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed

        if (this.jComboBox1.getSelectedIndex() == 0) {
            qtdTimes = 2;
            System.out.println(qtdTimes);
            campeonatos.get(contCamp).setNumeroDeTimes(2);

        } else if (this.jComboBox1.getSelectedIndex() == 1) {
            qtdTimes = 4;
            System.out.println(qtdTimes);
            campeonatos.get(contCamp).setNumeroDeTimes(4);

        } else if (this.jComboBox1.getSelectedIndex() == 2) {
            qtdTimes = 8;
            System.out.println(qtdTimes);
            campeonatos.get(contCamp).setNumeroDeTimes(8);

        }


    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jbtAvancarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtAvancarActionPerformed
        if (evt.getSource() == jbtAvancar) {
            if (qtdTimes == 2) {
                new GUI31().setVisible(true);
                GUI21.this.dispose();
            } else if (qtdTimes == 4) {
                new GUI32().setVisible(true);
                GUI21.this.dispose();
            }
    }//GEN-LAST:event_jbtAvancarActionPerformed
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI21().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JButton jbtAvancar;
    private javax.swing.JTextField jtfNomeDoCampeonato;
    // End of variables declaration//GEN-END:variables
}
